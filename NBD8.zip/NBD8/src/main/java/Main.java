import com.basho.riak.client.api.RiakClient;
import com.basho.riak.client.api.commands.kv.DeleteValue;
import com.basho.riak.client.api.commands.kv.FetchValue;
import com.basho.riak.client.api.commands.kv.StoreValue;
import com.basho.riak.client.core.query.Location;
import com.basho.riak.client.core.query.Namespace;
import com.basho.riak.client.core.query.RiakObject;
import com.basho.riak.client.core.util.BinaryValue;
import org.json.JSONObject;

import java.net.UnknownHostException;
import java.util.concurrent.ExecutionException;

public class Main {
    static RiakClient client;
    private static final String BUCKET = "s16405";
    private static final String HOST = "localhost";

    private static final Namespace quotesBucket = new Namespace(BUCKET);
    private static Location quoteObjectLocation;
    public static void main(String[] args) throws UnknownHostException, ExecutionException, InterruptedException {
        client = RiakClient.newClient(HOST);
        JSONObject document = createDocument();
        String key = document.getString("name");
        quoteObjectLocation = new Location(quotesBucket, key);
        //zapisanie
        save(document);

        //pobranie
        RiakObject riakObject = read();

        document = new JSONObject(riakObject.getValue().toStringUtf8());

        //wypisanie
        System.out.print("Pobrany dokument\t\t\t\t: ");
        System.out.println(document);

        //modyfikacja
        document.put("altered", true);

        //zapis zmodyfikowanego
        update(riakObject, document);

        //pobranie zmodyfikowanego
        riakObject = read();

        document = new JSONObject(riakObject.getValue().toStringUtf8());

        //wypisanie zmodyfikowanego
        System.out.print("Pobrany zmodyfikowany dokument\t: ");
        System.out.println(document);

        //usunięcie
        delete();

        //pobranie usuniętego
        riakObject = read();

        //wypisanie usuniętego
        System.out.print("Pobrany usunięty dokument\t\t: ");
        System.out.println(riakObject);

        client.shutdown();
    }

    private static JSONObject createDocument() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("name", "boat");
        jsonObject.put("wheels", 0);
        return jsonObject;
    }

    private static void save(JSONObject jsonObject) throws ExecutionException, InterruptedException {
        RiakObject quoteObject = new RiakObject()
                .setContentType("application/json")
                .setValue(BinaryValue.create(jsonObject.toString()));

        StoreValue storeOp = new StoreValue.Builder(quoteObject)
                .withLocation(quoteObjectLocation)
                .build();
        client.execute(storeOp);
    }

    private static void update(RiakObject riakObject, JSONObject document) throws ExecutionException, InterruptedException {
        riakObject.setValue(BinaryValue.create(document.toString()));
        StoreValue storeOp = new StoreValue.Builder(riakObject)
                .withLocation(quoteObjectLocation)
                .build();
        client.execute(storeOp);
    }

    private static void delete() throws ExecutionException, InterruptedException {
        DeleteValue deleteOp = new DeleteValue.Builder(quoteObjectLocation)
                .build();
        client.execute(deleteOp);
    }

    private static RiakObject read() throws ExecutionException, InterruptedException {
        Namespace ns = new Namespace("default",BUCKET);
        FetchValue fv = new FetchValue.Builder(quoteObjectLocation).build();
        FetchValue.Response response = client.execute(fv);
        return response.getValue(RiakObject.class);
    }
}
